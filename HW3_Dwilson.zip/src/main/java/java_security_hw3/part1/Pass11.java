package java_security_hw3.part1;

/**
 * This class does nothing. It will be manipulated to have a corrupt constants
 * section.
 */
public class Pass11 {

}
