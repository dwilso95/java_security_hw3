package java_security_hw3.part1;

/**
 * Superclass will be removed in byte code 
 */
public class Pass21 {

}
