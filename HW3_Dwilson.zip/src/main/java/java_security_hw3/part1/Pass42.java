package java_security_hw3.part1;

/**
 * Class will be modified to include a different name in the byte-code.
 */
public class Pass42 {

	public void doSomething(){
		
	}
	
}
