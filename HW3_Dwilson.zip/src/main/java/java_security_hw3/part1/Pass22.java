package java_security_hw3.part1;

/**
 * Class will be made to extend {@link HelperFinalClass}
 */
public class Pass22 {

}
