package java_security_hw3.part1;

/**
 * Field x will be changed to a string
 */
public class Pass32 {

	private final int x;

	public Pass32(int x) {
		this.x = x;
	}

	public int getX() {
		return x;
	}
}
