package java_security_hw3.part1;

/**
 * This class will will be changed to require java 9, which will not be used to
 * run the class.
 */
public class Pass12 {

}
