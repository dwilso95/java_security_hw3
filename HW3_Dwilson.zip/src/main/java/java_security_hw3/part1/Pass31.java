package java_security_hw3.part1;

/**
 * Parameters will be removed in byte code
 */
public class Pass31 {

	public int add(int a, int b){
		return a + b;
	}
}
