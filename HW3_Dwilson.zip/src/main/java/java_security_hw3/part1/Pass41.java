package java_security_hw3.part1;

/**
 * Method in the byte-code will be removed. 
 */
public class Pass41 {

	public void printHello() {
		System.out.println("Hello");
	}

}
