package java_security_hw3.part1;

public final class HelperFinalClass {

}
